"""
Shared module
"""
