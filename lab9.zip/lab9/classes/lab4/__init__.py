"""
Lab 4 module
"""
