"""
Art Generator package
"""
