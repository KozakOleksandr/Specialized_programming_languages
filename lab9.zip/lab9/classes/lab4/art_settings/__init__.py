"""
Art Settings package
"""
