"""
Lab 7 module
"""
