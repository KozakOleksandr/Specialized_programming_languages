"""
API error handling module
"""
