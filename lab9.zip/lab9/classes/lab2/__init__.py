"""
Lab 2 module
"""
