"""
Lab 8 module
"""
