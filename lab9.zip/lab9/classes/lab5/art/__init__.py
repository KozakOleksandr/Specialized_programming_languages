"""
Art package for lab5
"""