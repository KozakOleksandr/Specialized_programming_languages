"""
Shapes package for lab5
"""