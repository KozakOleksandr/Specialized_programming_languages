"""
Lab 5 module
"""
