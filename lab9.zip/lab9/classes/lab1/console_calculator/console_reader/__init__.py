"""
Console reader package
"""
