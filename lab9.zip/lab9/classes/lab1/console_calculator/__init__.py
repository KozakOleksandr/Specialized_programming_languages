"""
Console calculator package
"""
