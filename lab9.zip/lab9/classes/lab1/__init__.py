"""
Lab 1 module
"""
