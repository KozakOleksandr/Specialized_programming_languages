"""
Math operations package
"""
