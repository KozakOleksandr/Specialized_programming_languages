"""
Test package for lab6
"""