"""
Lab 6 module
"""
