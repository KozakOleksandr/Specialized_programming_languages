"""
Lab 3 module
"""
