"""
Figlet package
"""
